import 'package:flutter/material.dart';
import 'package:jmj_pototipo_flutter/contaPage.dart';
import 'package:jmj_pototipo_flutter/setores/alojamentoConjuntoPage.dart';
import 'package:jmj_pototipo_flutter/setores/casaDaGestantePage.dart';
import 'package:jmj_pototipo_flutter/setores/clinicaCirurgicaPage.dart';
import 'package:jmj_pototipo_flutter/setores/pediatriaPage.dart';
import 'package:jmj_pototipo_flutter/setores/prePartoPage.dart';
import 'package:jmj_pototipo_flutter/setores/utiNeonatalPage.dart';

class setoresPage extends StatefulWidget {
  @override
  _setoresPageState createState() => _setoresPageState();
}

class _setoresPageState extends State<setoresPage> {
  

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          title: Text("Setores",
            style: TextStyle(
              fontSize: 20.0,
              color: Colors.white,

            ),
          ),
          backgroundColor: Colors.redAccent[700],
          centerTitle: true,
          actions: <Widget>[
            IconButton(
              icon: Icon(Icons.account_circle), onPressed: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => contaPage()));
            },
            ),
          ],
        ),
        body: SingleChildScrollView(
          padding: EdgeInsets.all(15.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              FlatButton(
                child: Text("Alojamento Conjunto",
                style: TextStyle(
                  fontSize: 20.0,
                  color: Colors.redAccent[700]

                ),
                ),
                onPressed: (){
                  Navigator.push(context,
                  MaterialPageRoute(builder: (context) => alojamentoConjuntoPage()));
                },
              ),

        FlatButton(
          child: Text("Pré-Parto",
            style: TextStyle(
                fontSize: 20.0,
                color: Colors.redAccent[700]
            ),
          ),
          onPressed: (){
            Navigator.push(context,
                MaterialPageRoute(builder: (context) => prePartoPage()));
          },
        ),
              FlatButton(
                child: Text("Casa da Gestante",
                  style: TextStyle(
                      fontSize: 20.0,
                      color: Colors.redAccent[700]
                  ),
                ),
                onPressed: (){
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => casaDaGestantePage()));
                },
              ),
              FlatButton(
                child: Text("Clínica Cirurgica",
                  style: TextStyle(
                      fontSize: 20.0,
                      color: Colors.redAccent[700]
                  ),
                ),
                onPressed: (){
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => clinicaCirurgicaPage()));
                },
              ),
              FlatButton(
                child: Text("Pediatria",
                  style: TextStyle(
                      fontSize: 20.0,
                      color: Colors.redAccent[700]
                  ),
                ),
                onPressed: (){
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => pediatriaPage()));
                },
              ),
              FlatButton(
                child: Text("UTI Neonatal",
                  style: TextStyle(
                      fontSize: 20.0,
                      color: Colors.redAccent[700]
                  ),
                ),
                onPressed: (){
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => utiNeonatalPage()));
                },
              ),

            ],



)
          )

    );
  }

}

