import 'package:flutter/material.dart';

import '../adicionarPacientePage.dart';

class utiNeonatalPage extends StatefulWidget {
  @override
  _utiNeonatalPageState createState() => _utiNeonatalPageState();
}

class _utiNeonatalPageState extends State<utiNeonatalPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold (
      backgroundColor: Colors.white,
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          "UTI Neonatal",
          style: TextStyle(
              color: Colors.white,
              fontSize: 20.0
          ),
        ),
        backgroundColor: Colors.redAccent[700],

      ),
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.add,
          color: Colors.redAccent[700],
        ),
        backgroundColor: Colors.white70,
        onPressed: (){
          Navigator.push(context,
              MaterialPageRoute(builder: (context) => adicionarPacientePage()));
        },
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(15.0),

      ),

    );
  }
}
