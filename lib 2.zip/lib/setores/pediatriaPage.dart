import 'package:flutter/material.dart';
import 'package:jmj_pototipo_flutter/adicionarPacientePage.dart';

class pediatriaPage extends StatefulWidget {
  @override
  _pediatriaPageState createState() => _pediatriaPageState();
}

class _pediatriaPageState extends State<pediatriaPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold (
      backgroundColor: Colors.white,
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          "Pediatria",
          style: TextStyle(
              color: Colors.white,
              fontSize: 20.0
          ),
        ),
        backgroundColor: Colors.redAccent[700],

      ),
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.add,
          color: Colors.redAccent[700],
        ),
        backgroundColor: Colors.white70,
        onPressed: (){
          Navigator.push(context,
              MaterialPageRoute(builder: (context) => adicionarPacientePage()));
        },
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(15.0),

      ),

    );
  }
}
