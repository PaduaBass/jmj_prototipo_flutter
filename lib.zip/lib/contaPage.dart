import 'package:flutter/material.dart';
import 'package:jmj_pototipo_flutter/loginPage.dart';

class contaPage extends StatefulWidget {
  @override
  _contaPageState createState() => _contaPageState();
}

class _contaPageState extends State<contaPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold (
      appBar: AppBar(
        title: Text("Minha Conta",
        style: TextStyle(
          fontSize: 20.0,
          color: Colors.white
        ),
        ),
        backgroundColor: Colors.redAccent[700],
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(10.0),
        child: Column(
          children: <Widget>[
            Padding(
              padding: EdgeInsets.fromLTRB(80.0, 25.0, 80.0, 15.0),
              child: Container(
                height: 40.0,
                child: RaisedButton(onPressed: (){
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => loginPage()));
                },
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30.0)
                  ),
                  child:

                  Text("Sair",
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 20.0

                    ),
                  ),
                  color: Colors.redAccent[700],
                ),
              ),

            ),
          ],
        ),
      ),

    );
  }
}
