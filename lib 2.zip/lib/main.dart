import 'package:flutter/material.dart';
import 'package:jmj_pototipo_flutter/loginPage.dart';
import 'package:jmj_pototipo_flutter/setoresPage.dart';


import 'contaPage.dart';

void main (){
  runApp(MaterialApp(
    home: loginPage(),
    debugShowCheckedModeBanner: false,
    routes: <String, WidgetBuilder> {
      '/loginPage': (context) => loginPage(),
      '/setoresPage': (context) => setoresPage(),

  },
  ));
}