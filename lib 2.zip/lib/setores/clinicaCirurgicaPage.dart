import 'package:flutter/material.dart';

import '../adicionarPacientePage.dart';


class clinicaCirurgicaPage extends StatefulWidget {
  @override
  _clinicaCirurgicaPageState createState() => _clinicaCirurgicaPageState();
}

class _clinicaCirurgicaPageState extends State<clinicaCirurgicaPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold (
      backgroundColor: Colors.white,
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          "Clínica Cirurgica",
          style: TextStyle(
              color: Colors.white,
              fontSize: 20.0
          ),
        ),
        backgroundColor: Colors.redAccent[700],

      ),
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.add,
          color: Colors.redAccent[700],
        ),
        backgroundColor: Colors.white70,
        onPressed: (){
          Navigator.push(context,
              MaterialPageRoute(builder: (context) => adicionarPacientePage()));
        },
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(15.0),

      ),

    );
  }
}
