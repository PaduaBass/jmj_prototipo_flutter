import 'package:flutter/material.dart';
import 'package:jmj_pototipo_flutter/loginPage.dart';


import 'adicionarPacientePage.dart';

void main (){
  runApp(MaterialApp(
    home: loginPage()
  ));
}